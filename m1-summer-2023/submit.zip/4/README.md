# CMSC 430 Midterm 1, Part 4

## Instructions

You've been provided an implementation of Dupe as presented in class.

Your job is to implement `odd?`, a primitive operation that determines
whether a given integer is odd or not.

Update all relevant parts of Dupe to add the `odd?` primitive to the
language, both in the interpreter and compiler.

You may assume inputs to `odd?` are always integers.

Note: there are no `odd?` tests included, so you consider writing some
of your own.
