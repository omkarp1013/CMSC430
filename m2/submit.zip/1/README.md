# CMSC 430 Midterm 2, Part 1


## Instructions

Replace the `TODO` in `pledge.rkt` with your name to indicate you've read and
agree to the pledge.
