# CMSC 430 Midterm 1, Part 4

## Instructions

You've been provided a completely unmodified implementation of Extort;
it is exactly the code covered in class and in the notes.

Add everything you need to extend the language with the `void?` unary
primitive to the language.  It should work the same as it does in
Racket.
