#ifndef TYPES_H
#define TYPES_H

#define val_true  1
#define val_false 0

#endif
